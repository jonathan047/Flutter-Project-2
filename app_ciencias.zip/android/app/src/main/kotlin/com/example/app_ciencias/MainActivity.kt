package com.example.app_ciencias

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
