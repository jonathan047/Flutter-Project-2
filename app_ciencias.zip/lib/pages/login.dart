import 'package:app_ciencias/appbar.dart';
import 'package:app_ciencias/inputs.dart';
import 'package:app_ciencias/scrollable.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formkey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordCotroller = TextEditingController();
  bool _rememberMeChecked = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        title: "Login Our App",
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Form(
          key: _formkey,
          child: ScrollableColumn(children: [
            CustomInputField(
              keyboardType: TextInputType.emailAddress,
              hintText: 'Email',
              controller: _emailController,
              validator: (String? email) {
                if (email == null) {
                  return null;
                }
                bool emailvalid = RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                    .hasMatch(email);
                return emailvalid ? null : "Email is not valid";
              },
            ),
            SizedBox(
              height: 24,
            ),
            CustomInputField(
              keyboardType: TextInputType.visiblePassword,
              hintText: 'Senha',
              controller: _passwordCotroller,
              obscureText: true,
              validator: (String? password) {
                if (password == null) {
                  return null;
                }
                if (password.length < 7) {
                  return 'Senha muito curta';
                }
              },
            ),
            SizedBox(
              height: 24,
            ),
            CustomCheckBox(
              labelText: "Remember me",
              value: _rememberMeChecked,
              onChanged: (checked) =>
                  setState(() => _rememberMeChecked = checked ?? false),
            ),
            SizedBox(
              height: 24,
            ),
            ElevatedButton(
              onPressed: () {
                if (_formkey.currentState!.validate()) {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil('/home', (route) => false);
                  print('ok');
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content:
                          Text('Unhandled auth error ${_passwordCotroller}')));
                }
              },
              child: Text('Login'),
            ),
            Expanded(
              child: Container(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  "Don't have an account",
                  style: TextStyle(
                    color: Color(0xFFb8b8b8),
                  ),
                ),
                TextButton(
                  child: Text("Register"),
                  onPressed: () =>
                      {Navigator.of(context).pushNamed("/registrar")},
                ),
              ],
            ),
            SizedBox(
              height: 25,
            )
          ]),
        ),
      ),
    );
  }
}
