import 'dart:async';

import 'package:flutter/material.dart';

class SlashPage extends StatefulWidget {
  @override
  State<SlashPage> createState() => _SlashPageState();
}

class _SlashPageState extends State<SlashPage> {
  Timer? _timer;
  @override
  void initState() {
    super.initState();
    _timer = new Timer(
      Duration(seconds: 2, milliseconds: 500),
      () {
        String? userUser = '';
        if (userUser == '') {
          Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
        } else {
          Navigator.of(context).pushNamedAndRemoveUntil('/home', (_) => false);
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset('assets/bolsa-de-estudos.png', width: 200, height: 200),
            SizedBox(
              height: 16,
            ),
            Text(
              'Studies App',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500),
            )
          ],
        ),
      ),
    );
  }
}
