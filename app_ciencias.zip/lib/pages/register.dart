import 'package:app_ciencias/appbar.dart';
import 'package:app_ciencias/scrollable.dart';
import 'package:flutter/material.dart';

import '../inputs.dart';
// import 'inputs.dart';

class RegisterPage extends StatefulWidget {
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formkey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordCotroller = TextEditingController();
  final _passwordConfirmedController = TextEditingController();
  bool _agreeWithTerms = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        title: "Register Our Account",
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Form(
          key: _formkey,
          child: ScrollableColumn(children: [
            CustomInputField(
              keyboardType: TextInputType.emailAddress,
              hintText: 'Email',
              controller: _emailController,
              validator: (String? email) {
                if (email == null) {
                  return null;
                }
                bool emailvalid = RegExp(
                        r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                    .hasMatch(email);
                return emailvalid ? null : "Email is not valid";
              },
            ),
            SizedBox(
              height: 24,
            ),
            CustomInputField(
              keyboardType: TextInputType.visiblePassword,
              hintText: 'Senha',
              controller: _passwordCotroller,
              obscureText: true,
              validator: (String? password) {
                if (password == null) {
                  return null;
                }
                if (password.length < 5) {
                  return 'Senha muito curta';
                }
              },
            ),
            SizedBox(
              height: 24,
            ),
            CustomInputField(
                keyboardType: TextInputType.visiblePassword,
                hintText: 'Confirmar senha',
                controller: _passwordConfirmedController,
                obscureText: true,
                validator: (String? password) {
                  if (password == null) {
                    return null;
                  }
                  if (password != _passwordConfirmedController.value.text) {
                    return 'Senha não confirmada';
                  }
                }),
            SizedBox(
              height: 24,
            ),
            CustomCheckBox(
              label: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(8),
                    child: Text(
                      "By creating an account you agree to our",
                      style: TextStyle(
                        color: Color(0xFFa8a8a7),
                      ),
                    ),
                  ),
                  TextButton(
                    child: Text('Terms & Conditions'),
                    onPressed: () {
                      print("// Terms & Conditions");
                    },
                  ),
                ],
              ),
              value: _agreeWithTerms,
              onChanged: (checked) =>
                  setState(() => _agreeWithTerms = checked ?? false),
            ),
            SizedBox(
              height: 24,
            ),
            ElevatedButton(
              onPressed: !_agreeWithTerms
                  ? null
                  : () {
                      if (_formkey.currentState!.validate()) {
                        Navigator.of(context)
                            .pushNamedAndRemoveUntil('/home', (route) => false);
                        print('ok');
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text(
                                'Unhandled auth error ${_passwordCotroller}')));
                      }
                    },
              child: Text('Registar'),
            ),
            Expanded(
              child: Container(),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  "Don't have an account",
                  style: TextStyle(
                    color: Color(0xFFb8b8b8),
                  ),
                ),
                TextButton(
                  child: Text("Login"),
                  onPressed: () => {Navigator.of(context).pushNamed("/login")},
                ),
              ],
            ),
            SizedBox(
              height: 25,
            ),
          ]),
        ),
      ),
    );
    ;
  }
}
