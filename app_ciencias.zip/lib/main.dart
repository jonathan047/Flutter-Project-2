import 'package:app_ciencias/myapp.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());
