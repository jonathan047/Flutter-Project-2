import 'package:flutter/material.dart';

class CustomAppbar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  CustomAppbar({required this.title}) {}

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 16),
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 200,
            child: Text(
              title,
              maxLines: 6,
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 29,
              ),
            ),
          ),
          SizedBox(
            height: 16,
          ),
          Row(
            children: [
              Container(
                width: 100,
                height: 4,
                color: Colors.teal,
              ),
              SizedBox(
                width: 4,
              ),
              Container(
                width: 15,
                height: 4,
                color: Colors.teal,
              )
            ],
          ),
        ],
      ),
    );
  }

  @override
  // TODO: implement preferredSize
  Size get preferredSize => Size.fromHeight(136);
}
