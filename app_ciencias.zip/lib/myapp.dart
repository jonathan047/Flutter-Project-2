// import 'package:app_ciencias/home.dart';
// import 'package:app_ciencias/register.dart';
import 'package:app_ciencias/pages/home.dart';
import 'package:app_ciencias/pages/login.dart';
import 'package:app_ciencias/pages/register.dart';
import 'package:app_ciencias/pages/slash_screem.dart';
import 'package:flutter/material.dart';
// import 'login.dart';
// import 'register.dart';

class MyApp extends StatelessWidget {
  final mainColor = Colors.teal;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(mainColor),
            minimumSize: MaterialStateProperty.all(
              Size.fromHeight(60),
            ),
            shape: MaterialStateProperty.all(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
            ),
          ),
        ),
      ),
      initialRoute: '/',
      // '/login',
      routes: {
        '/': (context) => SlashPage(),
        '/registrar': (context) => RegisterPage(),
        '/login': (context) => LoginPage(),
        '/home': (context) => HomePage(),
      },
    );
  }
}
